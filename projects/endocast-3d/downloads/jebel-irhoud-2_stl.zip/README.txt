Jebel Irhoud 2 (Homo sapiens) -- endocast 3D scan
================================================================

Full-resolution surface scan of a cast of the Jebel Irhoud 2 endocast, from the
Wolpoff Paleoanthropology Laboratory, University of Michigan.

Scanned 2015 with a Creaform HandyScan 3D REVscan at the University of
Michigan 3D Laboratory; stitched and processed in Materialise 3-matic.
Units: millimetres. 520,528 triangles.

Scan: Caleb C. Vogt, ANTHRBIO 474 Hominid Origins, University of Michigan.
Project page: https://calebvogt.github.io/projects/endocast-3d/

License: Creative Commons Attribution 4.0 International (CC BY 4.0)
https://creativecommons.org/licenses/by/4.0/
Please credit "Caleb C. Vogt (2015), endocast 3D scans" when you use it.

This is a scan of a cast, not of the original fossil, and carries the
cast's limits: surface detail is only as good as the casting.
